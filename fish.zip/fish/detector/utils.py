import cv2
import numpy as np
from PyQt5 import QtGui, QtCore

def convert_cv_to_qpixmap(cv_image, target_width=None, target_height=None):
    """将OpenCV图像转换为QPixmap"""
    if cv_image is None:
        return None
        
    try:
        if len(cv_image.shape) == 3:
            image_rgb = cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB)
        else:
            image_rgb = cv2.cvtColor(cv_image, cv2.COLOR_GRAY2RGB)
            
        h, w, ch = image_rgb.shape
        bytes_per_line = ch * w
        
        qt_image = QtGui.QImage(image_rgb.data, w, h, bytes_per_line, QtGui.QImage.Format_RGB888)
        
        pixmap = QtGui.QPixmap.fromImage(qt_image)
        
        if target_width and target_height:
            scaled_pixmap = pixmap.scaled(
                target_width, 
                target_height,
                QtCore.Qt.KeepAspectRatio,
                QtCore.Qt.SmoothTransformation
            )
            return scaled_pixmap
            
        return pixmap
        
    except Exception as e:
        print(f"图像转换错误: {str(e)}")
        return None

def calculate_real_length(pixel_length, pixels_per_cm):
    """计算实际长度"""
    return pixel_length / pixels_per_cm