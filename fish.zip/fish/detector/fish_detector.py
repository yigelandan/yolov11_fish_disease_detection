import os
import cv2
import numpy as np
import json
import traceback
import logging
from PIL import Image, ImageDraw, ImageFont
from ultralytics import YOLO

class FishKeypointDetector:
    def __init__(self, weights_path, config_path=None):
        self.weights_path = weights_path
        self.config = {}
        
        # 加载配置文件
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf8') as fp:
                    self.config = json.load(fp)
                logging.info(f'配置文件加载成功: {self.config}')
            except Exception as e:
                logging.error(f"配置文件加载失败: {str(e)}")
        
        try:
            device = self.config.get('device', 'cpu')
            logging.info(f"正在加载模型: {weights_path}")
            self.model = YOLO(weights_path)
            logging.info(f"关键点检测模型加载成功，设备: {device}")
        except Exception as e:
            logging.error(f"模型加载失败: {str(e)}")
            self.model = None

    def calculate_distance(self, p1, p2):
        """计算两点之间的欧氏距离（像素）"""
        return np.linalg.norm(np.array(p2) - np.array(p1))

    def midpoint(self, p1, p2):
        """计算线段中点坐标"""
        return [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2]

    def detect(self, image, conf_threshold=0.5, iou_threshold=0.45):
        if self.model is None:
            return [], image, "模型未加载"
        
        try:
            logging.info(f"开始检测，置信度阈值: {conf_threshold}, IOU阈值: {iou_threshold}")
            
            # 执行关键点预测
            results = self.model.predict(
                source=image,
                imgsz=self.config.get('imgsz', 640),
                conf=conf_threshold,
                iou=iou_threshold,
                device=self.config.get('device', 'cpu'),
                verbose=False
            )

            detection_info = []
            
            # 使用YOLO的plot方法绘制结果
            plotted_img = results[0].plot()
            result_image = plotted_img

            for result in results:
                # 检查是否有检测结果
                if result.boxes is None or len(result.boxes) == 0:
                    logging.info("未检测到任何目标")
                    continue
                    
                # 检查是否有关键点
                if result.keypoints is None:
                    logging.info("检测到目标但无关键点")
                    # 只有边界框检测，没有关键点
                    for box in result.boxes:
                        class_name = result.names[int(box.cls)]
                        bbox = box.xyxy[0].tolist()
                        
                        # 计算边界框长度作为估计
                        bbox_width = bbox[2] - bbox[0]
                        bbox_height = bbox[3] - bbox[1]
                        estimated_length = max(bbox_width, bbox_height)
                        
                        detection_info.append({
                            "class": class_name,
                            "confidence": float(box.conf),
                            "bbox": bbox,
                            "keypoints": None,
                            "lengths": {
                                "head_mid": 0,
                                "mid_tail": 0,
                                "total": float(estimated_length)
                            }
                        })
                    continue
                
                # 有关键点的情况
                for box, kp in zip(result.boxes, result.keypoints):
                    class_name = result.names[int(box.cls)]

                    # 提取关键点坐标
                    kp_coords = kp.xy[0].cpu().numpy()
                    
                    if len(kp_coords) < 3:
                        logging.warning(f"关键点数量不足: {len(kp_coords)}")
                        continue
                        
                    head = kp_coords[0].tolist()
                    mid = kp_coords[1].tolist()
                    tail = kp_coords[2].tolist()

                    # 计算各段长度
                    head_mid_length = self.calculate_distance(head, mid)
                    mid_tail_length = self.calculate_distance(mid, tail)
                    total_length = head_mid_length + mid_tail_length

                    detection_info.append({
                        "class": class_name,
                        "confidence": float(box.conf),
                        "bbox": box.xyxy[0].tolist(),
                        "keypoints": {
                            "head": head,
                            "mid": mid,
                            "tail": tail
                        },
                        "lengths": {
                            "head_mid": float(head_mid_length),
                            "mid_tail": float(mid_tail_length),
                            "total": float(total_length)
                        }
                    })

            # 如果有关键点检测，添加更详细的标注
            if detection_info and any(det['keypoints'] for det in detection_info):
                try:
                    # 使用PIL进行更精细的绘制
                    plotted_img_pil = Image.fromarray(cv2.cvtColor(plotted_img, cv2.COLOR_BGR2RGB))
                    draw = ImageDraw.Draw(plotted_img_pil)

                    try:
                        font = ImageFont.truetype("arial.ttf", 28)
                    except:
                        font = ImageFont.load_default()

                    # 绘制分段标注
                    for detection in detection_info:
                        if detection['keypoints'] is None:
                            continue
                            
                        # 获取坐标点
                        head = detection['keypoints']['head']
                        mid = detection['keypoints']['mid']
                        tail = detection['keypoints']['tail']
                        bbox = detection['bbox']

                        # 绘制分段连线
                        line_color = (255, 0, 0)
                        text_color = (0, 255, 0)

                        # 绘制头到中部线段
                        draw.line([tuple(head), tuple(mid)], fill=line_color, width=5)
                        # 在中段显示长度
                        hm_mid = self.midpoint(head, mid)
                        draw.text((hm_mid[0] + 5, hm_mid[1] - 15),
                                  f"{detection['lengths']['head_mid']:.1f}px",
                                  fill=text_color, font=font)

                        # 绘制中部到尾线段
                        draw.line([tuple(mid), tuple(tail)], fill=line_color, width=5)
                        # 在尾段显示长度
                        mt_mid = self.midpoint(mid, tail)
                        draw.text((mt_mid[0] + 5, mt_mid[1] - 15),
                                  f"{detection['lengths']['mid_tail']:.1f}px",
                                  fill=text_color, font=font)

                        # 在检测框顶部显示总长度
                        text_position = (int(bbox[0]), int(bbox[1]) - 50)
                        draw.text(text_position,
                                  f"Total: {detection['lengths']['total']:.1f}px",
                                  fill=(0, 0, 255),
                                  font=font)

                        # 绘制关键点
                        point_radius = 8
                        for point in [head, mid, tail]:
                            draw.ellipse([point[0]-point_radius, point[1]-point_radius,
                                         point[0]+point_radius, point[1]+point_radius],
                                        fill=(255, 255, 0))

                    # 转换回OpenCV格式
                    result_image = cv2.cvtColor(np.array(plotted_img_pil), cv2.COLOR_RGB2BGR)
                except Exception as e:
                    logging.error(f"绘制标注时出错: {str(e)}")

            status_msg = f"检测完成，共发现 {len(detection_info)} 个目标"
            if detection_info:
                status_msg += f"，其中 {sum(1 for d in detection_info if d['keypoints'])} 个目标有关键点"
            logging.info(status_msg)
            
            return detection_info, result_image, status_msg
        
        except Exception as e:
            logging.error(f"检测错误: {traceback.format_exc()}")
            return [], image, f"检测错误: {str(e)}"