import os
import cv2
import base64
import numpy as np
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from detector.fish_detector import FishKeypointDetector

# ===============================
# 基本配置
# ===============================

WEIGHTS_DIR = "weights"

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 开发阶段允许所有
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ===============================
# 权重管理
# ===============================

def get_weight_list():
    if not os.path.exists(WEIGHTS_DIR):
        return []
    return [f for f in os.listdir(WEIGHTS_DIR) if f.endswith(".pt")]

# 缓存 detector
detector_cache = {}

def get_detector(weight_name):
    weight_list = get_weight_list()

    if weight_name not in weight_list:
        raise ValueError("权重不存在")

    if weight_name not in detector_cache:
        model_path = os.path.join(WEIGHTS_DIR, weight_name)
        detector_cache[weight_name] = FishKeypointDetector(
            weights_path=model_path
        )

    return detector_cache[weight_name]

# ===============================
# 接口
# ===============================

@app.get("/weights")
def weights():
    return {"weights": get_weight_list()}

@app.post("/detect")
async def detect(
    file: UploadFile = File(...),
    weight_name: str = Form(...)
):
    contents = await file.read()

    nparr = np.frombuffer(contents, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    if img is None:
        return {"status": "图片读取失败"}

    try:
        detector = get_detector(weight_name)

        detection_info, result_img, status = detector.detect(img)

        _, buffer = cv2.imencode('.jpg', result_img)
        img_base64 = base64.b64encode(buffer).decode("utf-8")

        return {
            "status": status,
            "detections": detection_info,
            "image": img_base64
        }

    except Exception as e:
        return {"status": f"检测失败: {str(e)}"}

# ===============================
# 简单登录
# ===============================

USERNAME = "admin"
PASSWORD = "123456"

@app.post("/login")
async def login(username: str = Form(...), password: str = Form(...)):
    if username == USERNAME and password == PASSWORD:
        return {"success": True}
    return {"success": False, "message": "账号或密码错误"}