import sys
import os
import cv2
import logging
from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import QTimer
from detector.fish_detector import FishKeypointDetector
from detector.utils import convert_cv_to_qpixmap
from ui.custom_widgets import StyledButton, ModernGroupBox
from ui.styles import get_main_stylesheet

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        
        # 先初始化所有属性
        self.current_image = None
        self.cap = None
        self.timer = QTimer()
        self.detector = None
        self.pixels_per_cm = 10.0
        self.current_detections = []
        
        # 然后设置UI
        self.setupUi()
        
        # 最后连接信号和初始化
        self.timer.timeout.connect(self.update_frame)
        self.init_all()
        self.apply_styles()

    def setupUi(self):
        self.setObjectName("MainWindow")
        self.resize(1600, 1000)
        self.setMinimumSize(1400, 850)
        
        # 创建中心部件和主布局
        self.centralwidget = QtWidgets.QWidget(self)
        self.centralwidget.setObjectName("centralwidget")
        self.main_layout = QtWidgets.QHBoxLayout(self.centralwidget)
        self.main_layout.setContentsMargins(15, 15, 15, 15)
        self.main_layout.setSpacing(15)
        
        self.weights_dir = './weights'
        self.config_path = './config.json'
        
        # 左侧控制面板
        self.left_panel = QtWidgets.QWidget()
        self.left_panel.setMaximumWidth(450)
        left_layout = QtWidgets.QVBoxLayout(self.left_panel)
        left_layout.setSpacing(15)
        left_layout.setContentsMargins(15, 15, 15, 15)
        
        # 应用标题
        app_title = QtWidgets.QLabel("鱼类检测分析系统")
        app_title.setAlignment(QtCore.Qt.AlignCenter)
        app_title.setStyleSheet("""
            QLabel {
                font-size: 24px;
                font-weight: bold;
                color: #2E7D32;
                padding: 20px;
                background-color: #E8F5E9;
                border-radius: 12px;
                margin-bottom: 15px;
            }
        """)
        left_layout.addWidget(app_title)
        
        # 模型设置组
        model_group = ModernGroupBox("模型设置")
        model_layout = QtWidgets.QVBoxLayout(model_group)
        model_layout.setSpacing(15)
        
        self.label_2 = QtWidgets.QLabel("选择权重文件:")
        self.label_2.setStyleSheet("font-size: 16px; font-weight: bold; color: #37474F;")
        self.cb_weights = QtWidgets.QComboBox()
        self.cb_weights.setMinimumHeight(45)
        self.cb_weights.setObjectName("cb_weights")
        self.cb_weights.currentIndexChanged.connect(self.cb_weights_changed)
        
        model_layout.addWidget(self.label_2)
        model_layout.addWidget(self.cb_weights)
        left_layout.addWidget(model_group)
        
        # 参数设置组
        params_group = ModernGroupBox("检测参数")
        params_layout = QtWidgets.QVBoxLayout(params_group)
        params_layout.setSpacing(20)
        
        # 置信度设置
        conf_layout = QtWidgets.QVBoxLayout()
        self.label_3 = QtWidgets.QLabel("置信度:")
        self.label_3.setStyleSheet("font-size: 16px; font-weight: bold; color: #37474F;")
        self.hs_conf = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.hs_conf.setProperty("value", 50)
        self.hs_conf.setMinimumHeight(35)
        self.hs_conf.setObjectName("hs_conf")
        self.hs_conf.valueChanged.connect(self.conf_change)
        
        self.dsb_conf = QtWidgets.QDoubleSpinBox()
        self.dsb_conf.setMaximum(1.0)
        self.dsb_conf.setSingleStep(0.01)
        self.dsb_conf.setProperty("value", 0.5)
        self.dsb_conf.setMinimumHeight(40)
        self.dsb_conf.setObjectName("dsb_conf")
        self.dsb_conf.valueChanged.connect(self.dsb_conf_change)
        
        conf_layout.addWidget(self.label_3)
        conf_layout.addWidget(self.hs_conf)
        conf_layout.addWidget(self.dsb_conf)
        params_layout.addLayout(conf_layout)
        
        # IOU设置
        iou_layout = QtWidgets.QVBoxLayout()
        self.label_4 = QtWidgets.QLabel("IOU阈值:")
        self.label_4.setStyleSheet("font-size: 16px; font-weight: bold; color: #37474F;")
        self.hs_iou = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.hs_iou.setProperty("value", 45)
        self.hs_iou.setMinimumHeight(35)
        self.hs_iou.setObjectName("hs_iou")
        self.hs_iou.valueChanged.connect(self.iou_change)
        
        self.dsb_iou = QtWidgets.QDoubleSpinBox()
        self.dsb_iou.setMaximum(1.0)
        self.dsb_iou.setSingleStep(0.01)
        self.dsb_iou.setProperty("value", 0.45)
        self.dsb_iou.setMinimumHeight(40)
        self.dsb_iou.setObjectName("dsb_iou")
        self.dsb_iou.valueChanged.connect(self.dsb_iou_change)
        
        iou_layout.addWidget(self.label_4)
        iou_layout.addWidget(self.hs_iou)
        iou_layout.addWidget(self.dsb_iou)
        params_layout.addLayout(iou_layout)
        
        # 校准设置
        calibration_layout = QtWidgets.QHBoxLayout()
        self.label_calibration = QtWidgets.QLabel("像素/厘米:")
        self.label_calibration.setStyleSheet("font-size: 16px; font-weight: bold; color: #37474F;")
        self.dsb_pixels_per_cm = QtWidgets.QDoubleSpinBox()
        self.dsb_pixels_per_cm.setMinimum(0.1)
        self.dsb_pixels_per_cm.setMaximum(100.0)
        self.dsb_pixels_per_cm.setSingleStep(0.1)
        self.dsb_pixels_per_cm.setProperty("value", 10.0)
        self.dsb_pixels_per_cm.setMinimumHeight(40)
        self.dsb_pixels_per_cm.setObjectName("dsb_pixels_per_cm")
        self.dsb_pixels_per_cm.valueChanged.connect(self.calibration_changed)
        
        calibration_layout.addWidget(self.label_calibration)
        calibration_layout.addWidget(self.dsb_pixels_per_cm)
        params_layout.addLayout(calibration_layout)
        
        left_layout.addWidget(params_group)
        
        # 结果显示组
        results_group = ModernGroupBox("检测结果")
        results_layout = QtWidgets.QVBoxLayout(results_group)
        
        self.le_res = QtWidgets.QTextEdit()
        self.le_res.setObjectName("le_res")
        self.le_res.setStyleSheet("""
            QTextEdit {
                font-size: 15px;
                background-color: white;
                border: 2px solid #BDBDBD;
                border-radius: 8px;
                padding: 10px;
            }
        """)
        results_layout.addWidget(self.le_res)
        
        left_layout.addWidget(results_group)
        
        # 操作按钮
        self.btn_redetect = StyledButton("重新检测")
        self.btn_redetect.setObjectName("btn_redetect")
        self.btn_redetect.clicked.connect(self.redetect)
        left_layout.addWidget(self.btn_redetect)
        
        left_layout.addStretch()
        
        # 右侧图像显示区域
        self.right_panel = QtWidgets.QWidget()
        right_layout = QtWidgets.QVBoxLayout(self.right_panel)
        right_layout.setSpacing(15)
        right_layout.setContentsMargins(15, 15, 15, 15)
        
        # 图像显示标签
        image_frame = QtWidgets.QFrame()
        image_frame.setFrameShape(QtWidgets.QFrame.Box)
        image_frame.setStyleSheet("""
            QFrame { 
                background-color: #263238;
                border: 3px solid #BDBDBD; 
                border-radius: 12px; 
            }
        """)
        image_layout = QtWidgets.QVBoxLayout(image_frame)
        image_layout.setContentsMargins(10, 10, 10, 10)
        
        self.picture = QtWidgets.QLabel()
        self.picture.setAlignment(QtCore.Qt.AlignCenter)
        self.picture.setStyleSheet("""
            QLabel {
                background-color: transparent;
                color: #ECEFF1;
                font-size: 20px;
                min-height: 550px;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        self.picture.setText("请选择图像文件开始检测")
        self.picture.setScaledContents(False)
        
        image_layout.addWidget(self.picture)
        right_layout.addWidget(image_frame)
        
        # 状态信息栏
        self.status_label = QtWidgets.QLabel("就绪")
        self.status_label.setStyleSheet("""
            QLabel {
                background-color: #E3F2FD;
                color: #1565C0;
                padding: 15px;
                border-radius: 8px;
                font-weight: bold;
                font-size: 16px;
            }
        """)
        right_layout.addWidget(self.status_label)
        
        # 将左右面板添加到主布局
        self.main_layout.addWidget(self.left_panel)
        self.main_layout.addWidget(self.right_panel)
        
        self.setCentralWidget(self.centralwidget)
        
        # 创建菜单栏
        self.create_menubar()
        
        # 创建工具栏
        self.create_toolbar()
        
        self.retranslateUi()
        QtCore.QMetaObject.connectSlotsByName(self)

    def create_menubar(self):
        """创建菜单栏"""
        self.menubar = QtWidgets.QMenuBar(self)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1600, 35))
        
        # 文件菜单
        file_menu = self.menubar.addMenu("文件")
        file_menu.setStyleSheet("font-size: 14px;")
        
        self.actionopenpic = QtWidgets.QAction("打开图片", self)
        self.actionopenpic.triggered.connect(self.open_image)
        file_menu.addAction(self.actionopenpic)
        
        self.action = QtWidgets.QAction("打开视频", self)
        self.action.triggered.connect(self.open_video)
        file_menu.addAction(self.action)
        
        self.action_2 = QtWidgets.QAction("打开摄像头", self)
        self.action_2.triggered.connect(self.open_camera)
        file_menu.addAction(self.action_2)
        
        file_menu.addSeparator()
        
        self.action_save = QtWidgets.QAction("保存结果", self)
        self.action_save.triggered.connect(self.save_results)
        file_menu.addAction(self.action_save)
        
        file_menu.addSeparator()
        
        self.actionexit = QtWidgets.QAction("退出", self)
        self.actionexit.triggered.connect(self.exit)
        file_menu.addAction(self.actionexit)
        
        # 工具菜单
        tool_menu = self.menubar.addMenu("工具")
        tool_menu.setStyleSheet("font-size: 14px;")
        
        self.action_calibrate = QtWidgets.QAction("校准测量", self)
        self.action_calibrate.triggered.connect(self.calibrate_measurement)
        tool_menu.addAction(self.action_calibrate)
        
        self.setMenuBar(self.menubar)

    def create_toolbar(self):
        """创建工具栏"""
        self.toolBar = QtWidgets.QToolBar(self)
        self.toolBar.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.toolBar.setIconSize(QtCore.QSize(32, 32))
        self.toolBar.setMinimumHeight(50)
        
        # 添加工具栏动作
        self.toolBar.addAction(self.actionopenpic)
        self.toolBar.addAction(self.action)
        self.toolBar.addAction(self.action_2)
        self.toolBar.addSeparator()
        self.toolBar.addAction(self.action_calibrate)
        self.toolBar.addAction(self.action_save)
        self.toolBar.addSeparator()
        self.toolBar.addAction(self.actionexit)
        
        self.addToolBar(QtCore.Qt.TopToolBarArea, self.toolBar)

    def apply_styles(self):
        """应用整体样式"""
        self.setStyleSheet(get_main_stylesheet())

    def retranslateUi(self):
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle(_translate("MainWindow", "鱼类关键点检测与体长测量系统"))

    def init_all(self):
        """初始化所有组件"""
        # 加载权重文件
        self.load_weights()
        # 设置初始值
        self.hs_conf.setRange(0, 100)
        self.hs_iou.setRange(0, 100)
        
    def load_weights(self):
        """加载权重文件到下拉框"""
        if os.path.exists(self.weights_dir):
            weight_files = [f for f in os.listdir(self.weights_dir) 
                          if f.endswith('.pt')]
            if weight_files:
                self.cb_weights.addItems(weight_files)
            else:
                QtWidgets.QMessageBox.warning(self, "警告", "weights目录中没有找到.pt权重文件")
        else:
            QtWidgets.QMessageBox.warning(self, "警告", "未找到weights目录")

    def cb_weights_changed(self):
        """权重选择改变事件"""
        selected_weight = self.cb_weights.currentText()
        if selected_weight:
            weight_path = os.path.join(self.weights_dir, selected_weight)
            try:
                self.detector = FishKeypointDetector(weight_path, self.config_path)
                self.status_label.setText(f"已选择权重: {selected_weight}")
                if hasattr(self, 'current_image') and self.current_image is not None:
                    self.detect_image()
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "错误", f"加载模型失败: {str(e)}")

    def conf_change(self):
        """置信度滑块改变事件"""
        value = self.hs_conf.value() / 100.0
        self.dsb_conf.setValue(value)

    def dsb_conf_change(self):
        """置信度数值改变事件"""
        value = self.dsb_conf.value()
        self.hs_conf.setValue(int(value * 100))

    def iou_change(self):
        """IOU滑块改变事件"""
        value = self.hs_iou.value() / 100.0
        self.dsb_iou.setValue(value)

    def dsb_iou_change(self):
        """IOU数值改变事件"""
        value = self.dsb_iou.value()
        self.hs_iou.setValue(int(value * 100))

    def calibration_changed(self):
        """校准系数改变事件"""
        self.pixels_per_cm = self.dsb_pixels_per_cm.value()
        self.status_label.setText(f"校准系数已更新: {self.pixels_per_cm} 像素/厘米")
        if hasattr(self, 'current_detections') and self.current_detections:
            self.display_detection_results(self.current_detections)

    def open_image(self):
        """打开图片文件"""
        file_path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "选择图片", "", "图片文件 (*.jpg *.jpeg *.png *.bmp)")
        if file_path:
            self.current_image = cv2.imread(file_path)
            if self.current_image is not None:
                self.display_image(self.current_image)
                self.detect_image()
            else:
                QtWidgets.QMessageBox.critical(self, "错误", "无法加载图片")
                self.status_label.setText("无法加载图片")

    def open_video(self):
        """打开视频文件"""
        file_path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "选择视频", "", "视频文件 (*.mp4 *.avi *.mov)")
        if file_path:
            if self.timer.isActive():
                self.timer.stop()
            if self.cap:
                self.cap.release()
            
            self.cap = cv2.VideoCapture(file_path)
            if self.cap.isOpened():
                self.timer.start(30)
                self.status_label.setText(f"已打开视频: {file_path}")
            else:
                QtWidgets.QMessageBox.critical(self, "错误", "无法打开视频文件")
                self.status_label.setText("无法打开视频文件")

    def open_camera(self):
        """打开摄像头"""
        if self.timer.isActive():
            self.timer.stop()
        if self.cap:
            self.cap.release()
            
        self.cap = cv2.VideoCapture(0)
        if self.cap.isOpened():
            self.timer.start(30)
            self.status_label.setText("已打开摄像头")
        else:
            QtWidgets.QMessageBox.critical(self, "错误", "无法打开摄像头")
            self.status_label.setText("无法打开摄像头")

    def update_frame(self):
        """更新视频帧"""
        if self.cap and self.cap.isOpened():
            ret, frame = self.cap.read()
            if ret:
                self.display_image(frame)
                self.detect_image(frame)
            else:
                self.timer.stop()
                self.status_label.setText("视频播放完毕")

    def display_image(self, image):
        """显示图片到QLabel"""
        if image is None:
            return
            
        try:
            pixmap = convert_cv_to_qpixmap(image, self.picture.width(), self.picture.height())
            if pixmap:
                self.picture.setPixmap(pixmap)
            
        except Exception as e:
            logging.error(f"显示图像时出错: {str(e)}")
            self.status_label.setText(f"显示图像错误: {str(e)}")

    def detect_image(self, image=None):
        """检测图片"""
        if self.detector is None:
            self.le_res.setText("请先选择权重文件")
            return
            
        if image is None:
            image = self.current_image
            
        if image is not None:
            try:
                conf = self.dsb_conf.value()
                iou = self.dsb_iou.value()
                
                detection_info, result_image, status_msg = self.detector.detect(image, conf, iou)
                self.current_detections = detection_info
                
                self.display_image(result_image)
                self.display_detection_results(detection_info)
                self.status_label.setText(status_msg)
                
            except Exception as e:
                logging.error(f"检测过程中出错: {str(e)}")
                self.status_label.setText(f"检测错误: {str(e)}")

    def redetect(self):
        """重新检测当前图像"""
        if hasattr(self, 'current_image') and self.current_image is not None:
            self.detect_image()
        else:
            QtWidgets.QMessageBox.warning(self, "警告", "没有可检测的图像")

    def display_detection_results(self, detection_info):
        """显示检测结果"""
        self.le_res.clear()
        
        if not detection_info:
            self.le_res.setText("未检测到目标")
            return
        
        class_count = {}
        total_objects = 0
        
        for i, detection in enumerate(detection_info):
            class_name = detection['class']
            confidence = detection['confidence']
            
            if detection['keypoints'] is not None:
                head_mid_length = detection['lengths']['head_mid']
                mid_tail_length = detection['lengths']['mid_tail']
                total_length_px = detection['lengths']['total']
                
                head_mid_cm = head_mid_length / self.pixels_per_cm
                mid_tail_cm = mid_tail_length / self.pixels_per_cm
                total_length_cm = total_length_px / self.pixels_per_cm
                
                length_info = f"  分段长度:\n    - 头到中: {head_mid_length:.1f}px ({head_mid_cm:.1f}cm)\n    - 中到尾: {mid_tail_length:.1f}px ({mid_tail_cm:.1f}cm)\n  总长度: {total_length_px:.1f}px ({total_length_cm:.1f}cm)"
            else:
                total_length_px = detection['lengths']['total']
                total_length_cm = total_length_px / self.pixels_per_cm
                length_info = f"  估计长度: {total_length_px:.1f}px ({total_length_cm:.1f}cm)\n  (基于边界框)"
            
            if class_name not in class_count:
                class_count[class_name] = 0
            class_count[class_name] += 1
            total_objects += 1
            
            result_text = f"目标 {i+1}:\n"
            result_text += f"  类别: {class_name}\n"
            result_text += f"  置信度: {confidence:.3f}\n"
            result_text += length_info + "\n"
            result_text += "-" * 40 + "\n"
            
            self.le_res.append(result_text)
        
        self.le_res.append("=" * 50)
        self.le_res.append("统计信息:")
        self.le_res.append(f"总检测数: {total_objects}")
        for class_name, count in class_count.items():
            self.le_res.append(f"{class_name}: {count}")

    def calibrate_measurement(self):
        """校准测量系统"""
        if not hasattr(self, 'current_image') or self.current_image is None:
            QtWidgets.QMessageBox.warning(self, "警告", "请先打开一张图片进行校准")
            return
        
        reply = QtWidgets.QMessageBox.question(self, "校准", 
                                             "请在图像上测量已知长度的物体，然后输入实际长度。\n是否继续?",
                                             QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
        
        if reply == QtWidgets.QMessageBox.Yes:
            length, ok = QtWidgets.QInputDialog.getDouble(self, "校准", 
                                                        "输入已知物体的实际长度(厘米):", 
                                                        value=10.0, min=0.1, max=100.0, decimals=1)
            if ok:
                pixel_length, ok2 = QtWidgets.QInputDialog.getDouble(self, "校准", 
                                                                   "输入物体在图像中的像素长度:", 
                                                                   value=100.0, min=1.0, max=1000.0, decimals=0)
                if ok2:
                    self.pixels_per_cm = pixel_length / length
                    self.dsb_pixels_per_cm.setValue(self.pixels_per_cm)
                    QtWidgets.QMessageBox.information(self, "校准完成", 
                                                    f"校准系数已设置为: {self.pixels_per_cm:.2f} 像素/厘米")
                    if hasattr(self, 'current_detections') and self.current_detections:
                        self.display_detection_results(self.current_detections)

    def save_results(self):
        """保存检测结果"""
        if not hasattr(self, 'current_detections') or not self.current_detections:
            QtWidgets.QMessageBox.warning(self, "警告", "没有可保存的检测结果")
            return
            
        file_path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "保存结果", "", "文本文件 (*.txt);;所有文件 (*)")
        
        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(self.le_res.toPlainText())
                QtWidgets.QMessageBox.information(self, "成功", "结果已保存")
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "错误", f"保存失败: {str(e)}")

    def exit(self):
        """退出程序"""
        if self.timer.isActive():
            self.timer.stop()
        if self.cap:
            self.cap.release()
        self.close()