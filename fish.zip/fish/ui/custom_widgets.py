from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtWidgets import QGraphicsDropShadowEffect

class StyledButton(QtWidgets.QPushButton):
    """自定义样式按钮"""
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setMinimumHeight(50)
        self.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))


class ModernGroupBox(QtWidgets.QGroupBox):
    """现代化分组框"""
    def __init__(self, title, parent=None):
        super().__init__(title, parent)
        self.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                font-size: 16px;
                border: 2px solid #4CAF50;
                border-radius: 10px;
                margin-top: 1ex;
                padding-top: 20px;
                background-color: rgba(255, 255, 255, 200);
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top center;
                padding: 8px 20px;
                background-color: #4CAF50;
                color: white;
                border-radius: 6px;
                font-size: 16px;
            }
        """)