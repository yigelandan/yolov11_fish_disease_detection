def get_main_stylesheet():
    """返回主应用程序样式表"""
    return """
        QMainWindow {
            background-color: #F5F5F5;
        }
        QWidget {
            font-family: 'Microsoft YaHei', 'Segoe UI', Arial;
            font-size: 14px;
        }
        QPushButton {
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 12px 24px;
            font-weight: bold;
            font-size: 16px;
        }
        QPushButton:hover {
            background-color: #45a049;
        }
        QPushButton:pressed {
            background-color: #3d8b40;
        }
        QComboBox {
            padding: 8px;
            border: 2px solid #BDBDBD;
            border-radius: 8px;
            background-color: white;
            font-size: 14px;
            min-height: 40px;
        }
        QComboBox:focus {
            border-color: #4CAF50;
        }
        QComboBox::drop-down {
            border: none;
        }
        QComboBox::down-arrow {
            image: none;
            border-left: 5px solid transparent;
            border-right: 5px solid transparent;
            border-top: 5px solid #757575;
            width: 0px;
            height: 0px;
        }
        QSlider::groove:horizontal {
            border: 1px solid #BDBDBD;
            height: 8px;
            background: #E0E0E0;
            border-radius: 5px;
        }
        QSlider::handle:horizontal {
            background-color: #4CAF50;
            border: 1px solid #388E3C;
            width: 20px;
            margin: -6px 0;
            border-radius: 10px;
        }
        QDoubleSpinBox {
            padding: 8px;
            border: 2px solid #BDBDBD;
            border-radius: 8px;
            background-color: white;
            font-size: 14px;
            min-height: 35px;
        }
        QDoubleSpinBox:focus {
            border-color: #4CAF50;
        }
        QTextEdit {
            border: 2px solid #BDBDBD;
            border-radius: 8px;
            padding: 10px;
            background-color: white;
            font-family: 'Consolas', 'Courier New', monospace;
            font-size: 13px;
        }
        QMenuBar {
            background-color: #2E7D32;
            color: white;
            font-weight: bold;
            font-size: 14px;
            border: none;
        }
        QMenuBar::item:selected {
            background-color: #4CAF50;
        }
        QMenu {
            background-color: white;
            border: 1px solid #BDBDBD;
            border-radius: 5px;
            font-size: 14px;
        }
        QMenu::item {
            padding: 8px 20px;
        }
        QMenu::item:selected {
            background-color: #E8F5E9;
            border-radius: 3px;
        }
        QToolBar {
            background-color: #E8F5E9;
            border: none;
            spacing: 8px;
            padding: 8px;
            border-radius: 5px;
        }
        QToolButton {
            background-color: #4CAF50;
            color: white;
            border-radius: 6px;
            padding: 8px 15px;
            font-size: 14px;
            min-height: 40px;
        }
        QToolButton:hover {
            background-color: #45a049;
        }
        QLabel {
            font-size: 14px;
        }
    """